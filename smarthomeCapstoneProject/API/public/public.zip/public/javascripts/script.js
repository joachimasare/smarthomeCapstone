$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();

  });

  function trigger_raspberry(function_name){
    console.log(function_name)
    $.get('http://2b6a375d.ngrok.io/ajax/', { function: function_name},
        function(returnedData){
            console.log(returnedData);
    });
}
  
  let authorize = async function(loc){
    let data = {
      status : "authorized"
    }
      const resp = await fetch(`http://127.0.0.1:8080/user/${loc}`,{
        method:'PUT',
        headers : {'Content-Type':'application/json'},
        body : JSON.stringify(data)
      })
      const myJ = await resp.json()
      alert(myJ.message)
  }

let unauthorize = async function(loc){
  data = {
    status : "unauthorized"
  }
  const resp = await fetch(`http://127.0.0.1:8080/user/${loc}`,{
        method:'PUT',
        headers : {'Content-Type':'application/json'},
        body : JSON.stringify(data)
      })
      const myJ = await resp.json()
      alert(myJ.message)
}


